# lights_ems
Basic EMS for managing the lights a the office of Cycle.
